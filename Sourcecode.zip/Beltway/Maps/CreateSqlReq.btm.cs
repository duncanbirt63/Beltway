namespace Beltway.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Beltway.schemas.StockUpdates", typeof(global::Beltway.schemas.StockUpdates))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Beltway.TypedProcedure_dbo+Updatestock", typeof(global::Beltway.TypedProcedure_dbo.Updatestock))]
    public sealed class CreateSqlReq : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0"" version=""1.0"" xmlns:s0=""http://Beltway.pipeline.StockUpdates"" xmlns:ns0=""http://schemas.microsoft.com/Sql/2008/05/TypedProcedures/dbo"" xmlns:ns3=""http://schemas.microsoft.com/Sql/2008/05/Types/TableTypes/dbo"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:StockUpdates"" />
  </xsl:template>
  <xsl:template match=""/s0:StockUpdates"">
    <ns0:Updatestock>
      <ns0:vwarehouse>
        <xsl:value-of select=""Warehouse/text()"" />
      </ns0:vwarehouse>
      <ns0:vStockinfo>
        <xsl:for-each select=""UpdateRecords"">
          <xsl:variable name=""var:v1"" select=""position()"" />
          <ns3:StockType>
            <ns3:ID>
              <xsl:value-of select=""$var:v1"" />
            </ns3:ID>
            <ns3:ProductCode>
              <xsl:value-of select=""ProductCode/text()"" />
            </ns3:ProductCode>
            <ns3:Level>
              <xsl:value-of select=""Qty/text()"" />
            </ns3:Level>
          </ns3:StockType>
        </xsl:for-each>
      </ns0:vStockinfo>
    </ns0:Updatestock>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _xsltEngine = @"";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Beltway.schemas.StockUpdates";
        
        private const global::Beltway.schemas.StockUpdates _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Beltway.TypedProcedure_dbo+Updatestock";
        
        private const global::Beltway.TypedProcedure_dbo.Updatestock _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltEngine {
            get {
                return _xsltEngine;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Beltway.schemas.StockUpdates";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Beltway.TypedProcedure_dbo+Updatestock";
                return _TrgSchemas;
            }
        }
    }
}
