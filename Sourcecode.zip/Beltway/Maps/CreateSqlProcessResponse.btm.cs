namespace Beltway.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Beltway.schemas.StockUpdates", typeof(global::Beltway.schemas.StockUpdates))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Beltway.schemas.SQLXmlResp", typeof(global::Beltway.schemas.SQLXmlResp))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Beltway.schemas.StockUpdateResp", typeof(global::Beltway.schemas.StockUpdateResp))]
    public sealed class CreateSqlProcessResponse : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 s1"" version=""1.0"" xmlns:ns0=""http://Beltway.schemas.StockUpdateResp"" xmlns:s1=""http://schemas.microsoft.com/BizTalk/2003/aggschema"" xmlns:s0=""http://Beltway.pipeline.StockUpdates"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s1:Root"" />
  </xsl:template>
  <xsl:template match=""/s1:Root"">
    <ns0:StockUpdatesResp>
      <Status>
        <xsl:value-of select=""InputMessagePart_1/UpdateResults/Status/text()"" />
      </Status>
      <xsl:for-each select=""InputMessagePart_1/UpdateResults/UpdateResult"">
        <xsl:variable name=""var:v1"" select=""Id/text()"" />
        <xsl:variable name=""var:v2"" select=""../../../InputMessagePart_0/s0:StockUpdates/UpdateRecords[number($var:v1)]/ProductCode/text()"" />
        <Response>
          <Status>
            <xsl:value-of select=""Status/text()"" />
          </Status>
          <Message>
            <xsl:value-of select=""Message/text()"" />
          </Message>
          <ProductCode>
            <xsl:value-of select=""$var:v2"" />
          </ProductCode>
        </Response>
      </xsl:for-each>
    </ns0:StockUpdatesResp>
  </xsl:template>
</xsl:stylesheet>";
        
        private const string _xsltEngine = @"";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Beltway.schemas.StockUpdates";
        
        private const global::Beltway.schemas.StockUpdates _srcSchemaTypeReference0 = null;
        
        private const string _strSrcSchemasList1 = @"Beltway.schemas.SQLXmlResp";
        
        private const global::Beltway.schemas.SQLXmlResp _srcSchemaTypeReference1 = null;
        
        private const string _strTrgSchemasList0 = @"Beltway.schemas.StockUpdateResp";
        
        private const global::Beltway.schemas.StockUpdateResp _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltEngine {
            get {
                return _xsltEngine;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [2];
                _SrcSchemas[0] = @"Beltway.schemas.StockUpdates";
                _SrcSchemas[1] = @"Beltway.schemas.SQLXmlResp";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Beltway.schemas.StockUpdateResp";
                return _TrgSchemas;
            }
        }
    }
}
