namespace Beltway.Maps {
    
    
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Beltway.schemas.StockUpdates", typeof(global::Beltway.schemas.StockUpdates))]
    [Microsoft.XLANGs.BaseTypes.SchemaReference(@"Beltway.schemas.erroremail", typeof(global::Beltway.schemas.erroremail))]
    public sealed class CreateEmail : global::Microsoft.XLANGs.BaseTypes.TransformBase {
        
        private const string _strMap = @"<?xml version=""1.0"" encoding=""UTF-16""?>
<xsl:stylesheet xmlns:xsl=""http://www.w3.org/1999/XSL/Transform"" xmlns:msxsl=""urn:schemas-microsoft-com:xslt"" xmlns:var=""http://schemas.microsoft.com/BizTalk/2003/var"" exclude-result-prefixes=""msxsl var s0 userCSharp"" version=""1.0"" xmlns:ns0=""http://Beltway.schemas.erroremail"" xmlns:s0=""http://Beltway.pipeline.StockUpdates"" xmlns:userCSharp=""http://schemas.microsoft.com/BizTalk/2003/userCSharp"">
  <xsl:output omit-xml-declaration=""yes"" method=""xml"" version=""1.0"" />
  <xsl:template match=""/"">
    <xsl:apply-templates select=""/s0:StockUpdates"" />
  </xsl:template>
  <xsl:template match=""/s0:StockUpdates"">
    <xsl:variable name=""var:v1"" select=""userCSharp:StringTrimLeft(&quot;Dummy&quot;)"" />
    <xsl:variable name=""var:v2"" select=""userCSharp:StringTrimLeft(&quot;BeltwayService&quot;)"" />
    <xsl:variable name=""var:v3"" select=""userCSharp:StringTrimLeft(&quot;EmailServer&quot;)"" />
    <ns0:erroremail>
      <Title>
        <xsl:value-of select=""$var:v1"" />
      </Title>
      <Message>
        <xsl:value-of select=""$var:v1"" />
      </Message>
      <from>
        <xsl:value-of select=""$var:v2"" />
      </from>
      <to>
        <xsl:value-of select=""$var:v1"" />
      </to>
      <emailserver>
        <xsl:value-of select=""$var:v3"" />
      </emailserver>
      <xsl:value-of select=""./text()"" />
    </ns0:erroremail>
  </xsl:template>
  <msxsl:script language=""C#"" implements-prefix=""userCSharp""><![CDATA[
public string StringTrimLeft(string str)
{
	if (str == null)
	{
		return """";
	}
	return str.TrimStart(null);
}



]]></msxsl:script>
</xsl:stylesheet>";
        
        private const string _xsltEngine = @"";
        
        private const int _useXSLTransform = 0;
        
        private const string _strArgList = @"<ExtensionObjects />";
        
        private const string _strSrcSchemasList0 = @"Beltway.schemas.StockUpdates";
        
        private const global::Beltway.schemas.StockUpdates _srcSchemaTypeReference0 = null;
        
        private const string _strTrgSchemasList0 = @"Beltway.schemas.erroremail";
        
        private const global::Beltway.schemas.erroremail _trgSchemaTypeReference0 = null;
        
        public override string XmlContent {
            get {
                return _strMap;
            }
        }
        
        public override string XsltEngine {
            get {
                return _xsltEngine;
            }
        }
        
        public override int UseXSLTransform {
            get {
                return _useXSLTransform;
            }
        }
        
        public override string XsltArgumentListContent {
            get {
                return _strArgList;
            }
        }
        
        public override string[] SourceSchemas {
            get {
                string[] _SrcSchemas = new string [1];
                _SrcSchemas[0] = @"Beltway.schemas.StockUpdates";
                return _SrcSchemas;
            }
        }
        
        public override string[] TargetSchemas {
            get {
                string[] _TrgSchemas = new string [1];
                _TrgSchemas[0] = @"Beltway.schemas.erroremail";
                return _TrgSchemas;
            }
        }
    }
}
